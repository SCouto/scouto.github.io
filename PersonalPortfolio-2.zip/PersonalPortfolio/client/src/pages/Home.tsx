import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import ArticlesSection from "@/components/ArticlesSection";
import TalksSection from "@/components/TalksSection";
import CoursesSection from "@/components/CoursesSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { useQuery } from "@tanstack/react-query";
import { Article, Course, Profile, Talk } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

function ProfileSkeleton() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center">
      <Skeleton className="h-16 w-64 mb-4" />
      <Skeleton className="h-6 w-96 mb-6" />
      <Skeleton className="h-64 w-full max-w-4xl" />
    </div>
  );
}

function ErrorDisplay({ message }: { message: string }) {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Alert variant="destructive" className="max-w-xl">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          {message}
        </AlertDescription>
      </Alert>
    </div>
  );
}

export default function Home() {
  const { data: profile, isLoading: profileLoading, error: profileError } = useQuery<Profile>({
    queryKey: ['/api/profile'],
  });
  
  const { data: articles, isLoading: articlesLoading, error: articlesError } = useQuery<Article[]>({
    queryKey: ['/api/articles'],
  });
  
  const { data: talks, isLoading: talksLoading, error: talksError } = useQuery<Talk[]>({
    queryKey: ['/api/talks'],
  });
  
  const { data: courses, isLoading: coursesLoading, error: coursesError } = useQuery<Course[]>({
    queryKey: ['/api/courses'],
  });
  
  const isLoading = profileLoading || articlesLoading || talksLoading || coursesLoading;
  
  if (isLoading) {
    return <ProfileSkeleton />;
  }
  
  if (profileError) {
    return <ErrorDisplay message="Failed to load profile data. Please try again later." />;
  }
  
  if (!profile) {
    return <ErrorDisplay message="Profile data not found." />;
  }

  return (
    <div className="bg-background text-foreground">
      <Header name={profile.name} />
      <main>
        <HeroSection profile={profile} />
        {!articlesError && articles ? (
          <ArticlesSection articles={articles} />
        ) : (
          <ErrorDisplay message="Failed to load articles. Please try again later." />
        )}
        
        {!talksError && talks ? (
          <TalksSection talks={talks} />
        ) : (
          <ErrorDisplay message="Failed to load talks. Please try again later." />
        )}
        
        {!coursesError && courses ? (
          <CoursesSection courses={courses} />
        ) : (
          <ErrorDisplay message="Failed to load courses. Please try again later." />
        )}
        
        <ContactSection linkedin={profile.linkedin} />
      </main>
      <Footer 
        name={profile.name} 
        title={profile.title} 
        linkedin={profile.linkedin}
        twitter={profile.twitter || undefined}
        github={profile.github || undefined}
      />
    </div>
  );
}
