import React from 'react';
import { Article } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, BookOpen, ExternalLink } from 'lucide-react';

interface ArticlesSectionProps {
  articles: Article[];
}

const ArticlesSection: React.FC<ArticlesSectionProps> = ({ articles }) => {
  return (
    <section id="articles" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Articles</h2>
          <p className="text-lg max-w-2xl mx-auto text-gray-600">
            Sharing insights and knowledge through in-depth technical writing.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {articles.map((article) => (
            <Card key={article.id} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow border border-gray-200/50">
              <img 
                src={article.image} 
                alt={article.title} 
                className="w-full h-48 object-cover"
              />
              <CardContent className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">{article.title}</h3>
                <p className="text-gray-600 mb-4">
                  {article.description}
                </p>
                <div className="flex items-center text-sm text-gray-500 mb-5">
                  <span className="mr-4 flex items-center">
                    <Calendar className="h-4 w-4 inline mr-1" />
                    {article.date}
                  </span>
                  <span className="flex items-center">
                    <BookOpen className="h-4 w-4 inline mr-1" />
                    {article.readTime}
                  </span>
                </div>
                <a 
                  href={article.link} 
                  className="inline-block text-primary font-medium hover:underline flex items-center" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  Read Article
                  <ExternalLink className="h-4 w-4 inline ml-1" />
                </a>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-10">
          <Button variant="secondary" asChild>
            <a href="https://example.com/all-articles" target="_blank" rel="noopener noreferrer" className="flex items-center">
              View All Articles
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 inline ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default ArticlesSection;
