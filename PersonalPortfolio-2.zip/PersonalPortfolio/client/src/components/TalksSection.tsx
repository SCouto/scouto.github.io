import React from 'react';
import { Talk } from '@shared/schema';
import { Calendar, Clock, ExternalLink } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

interface TalksSectionProps {
  talks: Talk[];
}

const TalksSection: React.FC<TalksSectionProps> = ({ talks }) => {
  return (
    <section id="talks" className="py-20 bg-gray-100/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Conference Talks</h2>
          <p className="text-lg max-w-2xl mx-auto text-gray-600">
            Presenting at conferences around the world on engineering topics and best practices.
          </p>
        </div>

        <div className="space-y-10">
          {talks.map((talk) => (
            <Card key={talk.id} className="bg-white rounded-lg overflow-hidden shadow-md border border-gray-200/50">
              <div className="md:flex">
                <div className="md:w-2/5 h-64 md:h-auto relative">
                  <div className="relative h-full">
                    <img 
                      src={talk.image} 
                      alt={talk.title} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <a 
                        href={talk.youtubeLink} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center shadow-lg"
                        aria-label="Watch on YouTube"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </a>
                    </div>
                  </div>
                </div>
                <CardContent className="p-6 md:w-3/5">
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{talk.title}</h3>
                  <div className="mb-4 text-sm text-gray-600">
                    <div className="flex items-center mb-2">
                      <Calendar className="h-4 w-4 mr-2" />
                      {talk.venue}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      {talk.date}
                    </div>
                  </div>
                  <p className="text-gray-600 mb-6">
                    {talk.description}
                  </p>
                  <a 
                    href={talk.youtubeLink} 
                    className="inline-block text-primary font-medium hover:underline flex items-center" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    Watch on YouTube
                    <ExternalLink className="h-4 w-4 inline ml-1" />
                  </a>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TalksSection;
