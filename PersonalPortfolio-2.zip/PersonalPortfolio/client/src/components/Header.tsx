import React, { useState } from 'react';
import { Link } from 'wouter';

interface HeaderProps {
  name: string;
}

const Header: React.FC<HeaderProps> = ({ name }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo/Name */}
        <Link href="/" className="text-2xl font-bold text-gray-900 flex items-center">
          <span>{name}</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#about" className="text-gray-600 hover:text-primary transition font-medium">About</a>
          <a href="#articles" className="text-gray-600 hover:text-primary transition font-medium">Articles</a>
          <a href="#talks" className="text-gray-600 hover:text-primary transition font-medium">Talks</a>
          <a href="#courses" className="text-gray-600 hover:text-primary transition font-medium">Courses</a>
          <a href="#contact" className="text-gray-600 hover:text-primary transition font-medium">Contact</a>
        </nav>

        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-gray-900 focus:outline-none"
          aria-label="Toggle mobile menu"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

      {/* Mobile Navigation Menu */}
      <div className={`${isMobileMenuOpen ? 'block' : 'hidden'} md:hidden bg-white border-t border-gray-200`}>
        <div className="container mx-auto px-4 py-3 flex flex-col space-y-3">
          <a 
            href="#about" 
            className="text-gray-600 hover:text-primary transition font-medium py-2"
            onClick={closeMobileMenu}
          >
            About
          </a>
          <a 
            href="#articles" 
            className="text-gray-600 hover:text-primary transition font-medium py-2"
            onClick={closeMobileMenu}
          >
            Articles
          </a>
          <a 
            href="#talks" 
            className="text-gray-600 hover:text-primary transition font-medium py-2"
            onClick={closeMobileMenu}
          >
            Talks
          </a>
          <a 
            href="#courses" 
            className="text-gray-600 hover:text-primary transition font-medium py-2"
            onClick={closeMobileMenu}
          >
            Courses
          </a>
          <a 
            href="#contact" 
            className="text-gray-600 hover:text-primary transition font-medium py-2"
            onClick={closeMobileMenu}
          >
            Contact
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;
