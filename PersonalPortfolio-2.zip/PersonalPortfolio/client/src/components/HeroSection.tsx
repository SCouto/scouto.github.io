import React from 'react';
import { Profile } from '@shared/schema';
import { Button } from '@/components/ui/button';

interface HeroSectionProps {
  profile: Profile;
}

const HeroSection: React.FC<HeroSectionProps> = ({ profile }) => {
  return (
    <section id="about" className="py-20 md:py-32 bg-gradient-to-b from-white to-gray-100/20">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10">
            <div className="relative w-64 h-64 mx-auto md:mx-0">
              <div className="absolute inset-0 rounded-full bg-primary/10"></div>
              <img 
                src={profile.avatar} 
                alt={profile.name} 
                className="rounded-full w-full h-full object-cover border-4 border-white shadow-lg"
              />
            </div>
          </div>
          <div className="md:w-1/2 text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">{profile.name}</h1>
            <h2 className="text-xl md:text-2xl text-primary font-medium mb-6">{profile.title}</h2>
            <p className="text-lg mb-8 leading-relaxed text-gray-600">
              {profile.bio}
            </p>
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <Button variant="default" asChild>
                <a href="#articles">Read My Articles</a>
              </Button>
              <Button variant="secondary" asChild>
                <a href="#contact">Get In Touch</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
