import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertArticleSchema, insertCourseSchema, insertProfileSchema, insertTalkSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the portfolio website
  const apiRouter = express.Router();
  
  // Profile endpoints
  apiRouter.get("/profile", async (req, res) => {
    try {
      const profile = await storage.getProfile();
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      return res.json(profile);
    } catch (error) {
      console.error("Error fetching profile:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Articles endpoints
  apiRouter.get("/articles", async (req, res) => {
    try {
      const articles = await storage.getArticles();
      return res.json(articles);
    } catch (error) {
      console.error("Error fetching articles:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/articles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const article = await storage.getArticle(id);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      
      return res.json(article);
    } catch (error) {
      console.error("Error fetching article:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/articles", async (req, res) => {
    try {
      const articleData = insertArticleSchema.parse(req.body);
      const newArticle = await storage.createArticle(articleData);
      return res.status(201).json(newArticle);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating article:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Talks endpoints
  apiRouter.get("/talks", async (req, res) => {
    try {
      const talks = await storage.getTalks();
      return res.json(talks);
    } catch (error) {
      console.error("Error fetching talks:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/talks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const talk = await storage.getTalk(id);
      if (!talk) {
        return res.status(404).json({ message: "Talk not found" });
      }
      
      return res.json(talk);
    } catch (error) {
      console.error("Error fetching talk:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/talks", async (req, res) => {
    try {
      const talkData = insertTalkSchema.parse(req.body);
      const newTalk = await storage.createTalk(talkData);
      return res.status(201).json(newTalk);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating talk:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Courses endpoints
  apiRouter.get("/courses", async (req, res) => {
    try {
      const courses = await storage.getCourses();
      return res.json(courses);
    } catch (error) {
      console.error("Error fetching courses:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.get("/courses/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }
      
      const course = await storage.getCourse(id);
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      return res.json(course);
    } catch (error) {
      console.error("Error fetching course:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  apiRouter.post("/courses", async (req, res) => {
    try {
      const courseData = insertCourseSchema.parse(req.body);
      const newCourse = await storage.createCourse(courseData);
      return res.status(201).json(newCourse);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error creating course:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Mount API routes
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}

import express from "express";
