import { users, type User, type InsertUser, type Article, type InsertArticle, articles, type Talk, type InsertTalk, talks, type Course, type InsertCourse, courses, type Profile, type InsertProfile, profile } from "@shared/schema";

export interface IStorage {
  // Users (keeping this as it was already defined)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Articles
  getArticles(): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  
  // Talks
  getTalks(): Promise<Talk[]>;
  getTalk(id: number): Promise<Talk | undefined>;
  createTalk(talk: InsertTalk): Promise<Talk>;
  
  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Profile
  getProfile(): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: number, profile: Partial<InsertProfile>): Promise<Profile | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private articlesList: Map<number, Article>;
  private talksList: Map<number, Talk>;
  private coursesList: Map<number, Course>;
  private profileData: Map<number, Profile>;
  
  currentUserId: number;
  currentArticleId: number;
  currentTalkId: number;
  currentCourseId: number;
  currentProfileId: number;

  constructor() {
    this.users = new Map();
    this.articlesList = new Map();
    this.talksList = new Map();
    this.coursesList = new Map();
    this.profileData = new Map();
    
    this.currentUserId = 1;
    this.currentArticleId = 1;
    this.currentTalkId = 1;
    this.currentCourseId = 1;
    this.currentProfileId = 1;
    
    // Initialize with sample data for profile
    this.createProfile({
      name: "John Doe",
      title: "Software Engineer & Technical Educator",
      bio: "I'm passionate about sharing knowledge through writing, speaking, and teaching. With over 10 years of experience in software development, I specialize in helping others understand complex technical concepts.",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80",
      linkedin: "https://www.linkedin.com/in/johndoe",
      twitter: "https://twitter.com/johndoe",
      github: "https://github.com/johndoe"
    });
    
    // Initialize with sample articles
    this.createArticle({
      title: "Understanding Modern JavaScript",
      description: "A deep dive into ES6+ features that have transformed how we write JavaScript.",
      image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340&q=80",
      link: "https://example.com/article1",
      date: "May 15, 2023",
      readTime: "10 min read"
    });
    
    this.createArticle({
      title: "The Future of State Management",
      description: "Exploring modern approaches to state management in front-end applications.",
      image: "https://images.unsplash.com/photo-1618044733300-9472054094ee?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340&q=80",
      link: "https://example.com/article2",
      date: "June 28, 2023",
      readTime: "12 min read"
    });
    
    this.createArticle({
      title: "Building Accessible Web Applications",
      description: "Best practices for creating inclusive applications that work for everyone.",
      image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=340&q=80",
      link: "https://example.com/article3",
      date: "August 10, 2023",
      readTime: "15 min read"
    });
    
    // Initialize with sample talks
    this.createTalk({
      title: "The Evolution of Front-End Development",
      description: "In this talk, I explore the major shifts in front-end development over the past decade, highlighting how component-based architectures and modern tooling have transformed our work.",
      image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&h=800&q=80",
      youtubeLink: "https://www.youtube.com/watch?v=example1",
      venue: "ReactConf 2023 - San Francisco, CA",
      date: "March 15, 2023"
    });
    
    this.createTalk({
      title: "Scaling Applications with Microservices",
      description: "A practical guide to decomposing monolithic applications into microservices, covering patterns, challenges, and implementation strategies for teams.",
      image: "https://images.unsplash.com/photo-1526925539332-aa3b66e35444?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&h=800&q=80",
      youtubeLink: "https://www.youtube.com/watch?v=example2",
      venue: "DevOps Summit 2022 - London, UK",
      date: "October 5, 2022"
    });
    
    // Initialize with sample courses
    this.createCourse({
      title: "Advanced React Patterns",
      description: "Master advanced React patterns like render props, compound components, and context API to build flexible and maintainable applications.",
      image: "https://images.unsplash.com/photo-1611926653458-09294b3142bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&h=400&q=80",
      link: "https://udemy.com/course/example1",
      students: "1,245",
      videoLength: "12 hours of video content",
      certificate: "Certificate upon completion",
      badge: "Bestseller",
      rating: "5"
    });
    
    this.createCourse({
      title: "Full-Stack JavaScript Development",
      description: "Complete guide to building modern web applications with Node.js, Express, React, and MongoDB. From zero to deployment.",
      image: "https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&h=400&q=80",
      link: "https://coursera.org/learn/example2",
      students: "847",
      videoLength: "20 hours of video content",
      certificate: "Certificate upon completion",
      badge: "New",
      rating: "5"
    });
  }

  // User methods (keeping these as they were already defined)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Article methods
  async getArticles(): Promise<Article[]> {
    return Array.from(this.articlesList.values());
  }
  
  async getArticle(id: number): Promise<Article | undefined> {
    return this.articlesList.get(id);
  }
  
  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = this.currentArticleId++;
    const article: Article = { ...insertArticle, id };
    this.articlesList.set(id, article);
    return article;
  }
  
  // Talk methods
  async getTalks(): Promise<Talk[]> {
    return Array.from(this.talksList.values());
  }
  
  async getTalk(id: number): Promise<Talk | undefined> {
    return this.talksList.get(id);
  }
  
  async createTalk(insertTalk: InsertTalk): Promise<Talk> {
    const id = this.currentTalkId++;
    const talk: Talk = { ...insertTalk, id };
    this.talksList.set(id, talk);
    return talk;
  }
  
  // Course methods
  async getCourses(): Promise<Course[]> {
    return Array.from(this.coursesList.values());
  }
  
  async getCourse(id: number): Promise<Course | undefined> {
    return this.coursesList.get(id);
  }
  
  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const id = this.currentCourseId++;
    const course: Course = { ...insertCourse, id };
    this.coursesList.set(id, course);
    return course;
  }
  
  // Profile methods
  async getProfile(): Promise<Profile | undefined> {
    // Get the first profile (there should be only one)
    if (this.profileData.size > 0) {
      return this.profileData.get(1);
    }
    return undefined;
  }
  
  async createProfile(insertProfile: InsertProfile): Promise<Profile> {
    const id = this.currentProfileId++;
    const profileEntry: Profile = { ...insertProfile, id };
    this.profileData.set(id, profileEntry);
    return profileEntry;
  }
  
  async updateProfile(id: number, profileUpdate: Partial<InsertProfile>): Promise<Profile | undefined> {
    const existingProfile = this.profileData.get(id);
    if (!existingProfile) {
      return undefined;
    }
    
    const updatedProfile: Profile = {
      ...existingProfile,
      ...profileUpdate,
    };
    
    this.profileData.set(id, updatedProfile);
    return updatedProfile;
  }
}

export const storage = new MemStorage();
